﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _07_Pais_Ciudad.Model;

namespace _07_Pais_Ciudad.Controllers
{
    internal class CiudadesController
    {
        CiudadesModel _ciudadesModel = new CiudadesModel();

        // Método para actualizar una ciudad
        public bool ActualizarCiudad(int idCiudad, string detalle, int idPais)
        {
            return _ciudadesModel.ActualizarCiudad(idCiudad, detalle, idPais);
        }

        // Método para obtener una ciudad por Id
        public CiudadesModel ObtenerCiudadPorId(int idCiudad)
        {
            return _ciudadesModel.ObtenerCiudadPorId(idCiudad);
        }

        public DataTable todosconrelacion()
        {
            return _ciudadesModel.todosconrelacion();
        }

    }
}


