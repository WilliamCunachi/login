﻿using _07_Pais_Ciudad.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _07_Pais_Ciudad.Controllers
{
    internal class UsuarioController
    {
        public UsuarioModel AutenticarUsuario(string usuarioNombre, string contraseña)
        {
            // Validamos el usuario usando el método en UsuarioModel
            return UsuarioModel.ValidarUsuario(usuarioNombre, contraseña);
        }
    }
}
