﻿using _07_Pais_Ciudad.Controllers;
using _07_Pais_Ciudad.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _07_Pais_Ciudad
{
    public partial class Form1 : Form
    {
        private UsuarioController usuarioController = new UsuarioController();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string usuarioNombre = txtUsuario.Text;
            string contraseña = txtContraseña.Text;

            // Autenticamos al usuario
            var usuario = usuarioController.AutenticarUsuario(usuarioNombre, contraseña);

            if (usuario != null)
            {
                // Validación exitosa, ahora revisamos el rol
                MessageBox.Show($"Bienvenido {usuario.UsuarioNombre}. Rol: {usuario.Rol}");

                // Aquí puedes redirigir al formulario correspondiente según el rol
                switch (usuario.Rol)
                {
                    case "Administrador":
                        ListaCiudades lista_Ciudades = new ListaCiudades();
                        lista_Ciudades.Show();
                        this.Hide(); // O usar this.Close(); si deseas cerrar el formulario de login

                        break;
                    case "Guardia":
                        GuardiaForm guardiaForm = new GuardiaForm();
                        guardiaForm.Show();
                        this.Hide();
                        
                        break;
                    case "Supervisor":
                       
                        break;

                    case "Conductor":
                        
                        break;
                }
            }
            else
            {
                MessageBox.Show("Usuario o contraseña incorrectos.");
            }
        }
    }
}

