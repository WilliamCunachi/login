﻿using _07_Pais_Ciudad.Config;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _07_Pais_Ciudad.Model
{
    internal class CiudadesModel
    {
        public int IdCiudad { get; set; }
        public string Detalle { get; set; }
        public int idPais { get; set; }
        public CiudadesModel ObtenerCiudadPorId(int idCiudad)
        {
            var query = "SELECT IdCiudad, Detalle, idPais FROM Ciudades WHERE IdCiudad = @IdCiudad";
            using (var cn = Conexion.GetConnection())
            {
                try
                {
                    using (SqlCommand cmd = new SqlCommand(query, cn))
                    {
                        cmd.Parameters.AddWithValue("@IdCiudad", idCiudad);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                CiudadesModel ciudad = new CiudadesModel
                                {
                                    IdCiudad = reader.GetInt32(0),
                                    Detalle = reader.GetString(1),
                                    idPais = reader.GetInt32(2)
                                };
                                return ciudad;
                            }
                        }
                    }
                }
                catch (SqlException ex)
                {
                    ErrorHandler.ManejarErrorSql(ex, "Error al obtener la ciudad.");
                }
                catch (Exception ex)
                {
                    ErrorHandler.ManejarErrorGeneral(ex, "Error al obtener la ciudad.");
                }
                return null;
            }
        }
        public bool ActualizarCiudad(int idCiudad, string detalle, int idPais)
        {
            var query = "UPDATE Ciudades SET Detalle = @Detalle, idPais = @IdPais WHERE IdCiudad = @IdCiudad";
            using (var cn = Conexion.GetConnection())
            {
                try
                {
                    using (SqlCommand cmd = new SqlCommand(query, cn))
                    {
                        cmd.Parameters.AddWithValue("@Detalle", detalle);
                        cmd.Parameters.AddWithValue("@IdPais", idPais);
                        cmd.Parameters.AddWithValue("@IdCiudad", idCiudad);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        return rowsAffected > 0;  // Retorna true si se actualiza al menos una fila
                    }
                }
                catch (SqlException ex)
                {
                    ErrorHandler.ManejarErrorSql(ex, "Error al actualizar la ciudad.");
                    return false;
                }
                catch (Exception ex)
                {
                    ErrorHandler.ManejarErrorGeneral(ex, "Error al actualizar la ciudad.");
                    return false;
                }
            }
        }

        public DataTable todosconrelacion()
        {
            var cadena = "SELECT Ciudades.IdCiudad, Ciudades.Detalle AS Ciudad, Paises.IdPais, Paises.Detalle AS 'Pais' FROM Ciudades INNER JOIN Paises ON Ciudades.idPais = Paises.IdPais";
            using (var cn = Conexion.GetConnection())
            {
                try
                {
                    SqlDataAdapter adaptador = new SqlDataAdapter(cadena, cn);
                    DataTable tabla = new DataTable();
                    adaptador.Fill(tabla);
                    return tabla;
                }
                catch (SqlException ex)
                {
                    ErrorHandler.ManejarErrorSql(ex, "Error al obtener las ciudades.");
                }
                catch (Exception ex)
                {
                    ErrorHandler.ManejarErrorGeneral(ex, "Error al obtener las ciudades.");
                }
                return null;
            }
        }

    }
}