﻿using _07_Pais_Ciudad.Config;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _07_Pais_Ciudad.Controllers;

namespace _07_Pais_Ciudad.Model
{
    internal class UsuarioModel
    {
        public int ID { get; set; }
        public string UsuarioNombre { get; set; }
        public string Contraseña { get; set; }
        public string Rol { get; set; }

        // Método para validar el login
        public static UsuarioModel ValidarUsuario(string usuarioNombre, string contraseña)
        {
            string query = "SELECT ID, usuario, roles FROM Usuarios WHERE usuario = @usuario AND contraseña = @contraseña";

            using (var cn = Conexion.GetConnection())
            {
                using (var cmd = new SqlCommand(query, cn))
                {
                    cmd.Parameters.AddWithValue("@usuario", usuarioNombre);
                    cmd.Parameters.AddWithValue("@contraseña", contraseña);

                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new UsuarioModel
                            {
                                ID = reader.GetInt32(0),
                                UsuarioNombre = reader.GetString(1),
                                Rol = reader.GetString(2)
                            };
                        }
                    }
                }
            }
            return null;
        }
    }
}
